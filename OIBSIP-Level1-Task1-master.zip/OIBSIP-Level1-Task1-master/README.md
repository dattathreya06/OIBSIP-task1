# OIBSIP-Level1-Task1

This is the Task-1 of Level-1 of the Oasis Infobyte Internship. In this task, I have made one Landing Page, this project demonstrates the fundamental understanding of HTML, CSS. Here, I learnt how to add columns, divide sections, arrange items, add headers, footers. Most importantly, I used my creativity to make the page look impressive. The alignments, the padding, the color palette, boxes and all the other elements on the page require attention.
